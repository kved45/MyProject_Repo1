import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Loan } from 'src/app/models/loan.model';
import { LoanApplication } from 'src/app/models/loanapplication.model';
import { LoanService } from 'src/app/services/loan.service';

@Component({
  selector: 'app-userviewloan',
  templateUrl: './userviewloan.component.html',
  styleUrls: ['./userviewloan.component.css']
})

export class UserviewloanComponent implements OnInit {

  alloans: Loan[] = [
    // { 
    //   loanId: 1, 
    //   loanType: 'Home Loan', 
    //   description: 'Home loan for renovation', 
    //   interestRate: 5.5, 
    //   maximumAmount: 5000000, 
    //   repaymentTenure: 20, 
    //   eligibility: 'Salaried and Self-employed individuals', 
    //   documentsRequired: 'ID proof, Address proof, Income proof'
    // },
    // { 
    //   loanId: 2, 
    //   loanType: 'Car Loan', 
    //   description: 'Car loan for new car', 
    //   interestRate: 7.2, 
    //   maximumAmount: 1000000, 
    //   repaymentTenure: 5, 
    //   eligibility: 'Salaried individuals', 
    //   documentsRequired: 'ID proof, Address proof, Income proof, Car quotation'
    // }


  ]
  appliedLoans:LoanApplication[]=[
    // {
    //   loanApplicationId: 102,
    //   user: { userId: 1, email: 'john.doe@example.com', password: 'password123', username: 'JohnDoe', mobileNumber: '1234567890', userRole: 'Farmer' },
    //   loan: { 
    //     loanId: 2, 
    //     loanType: 'Car Loan', 
    //     description: 'Car loan for new car', 
    //     interestRate: 7.2, 
    //     maximumAmount: 1000000, 
    //     repaymentTenure: 5, 
    //     eligibility: 'Salaried individuals', 
    //     documentsRequired: 'ID proof, Address proof, Income proof, Car quotation'
    //   },
    //   submissionDate: '2025-02-02',
    //   loanStatus: 2,
    //   farmLocation: '789 Farm Avenue',
    //   farmerAddress: '101 Farmer Lane',
    //   farmSizeInAcres: 20,
    //   farmPurpose: 'Livestock',
    //   file: 'car_loan_documents.pdf'
    // }
  ]

  currentUserId:number = parseInt(localStorage.getItem("userId"));



  searchData: string = "";


  constructor(private ls: LoanService, private router:Router) { }
  ngOnInit(): void {
    this.getAllLoans();
    this.getAllAppliedLoans();
  }
  getAllLoans() {
  this.ls.getAllLoans().subscribe(data => {
    console.log("Get All Loans")
    console.log(data);
    this.alloans = data;
    console.log("List of loans"+data)
  }, error=>{
    this.router.navigate(['/error'])
  })

  }

 getAllAppliedLoans() {
   this.ls.getAppliedLoans(this.currentUserId).subscribe(data => {
    console.log("Check inside appliedloan subscribe.")
    console.log(data);
    if (data && data.length > 0) {
      this.appliedLoans=data;
    } else {
       console.log('No applied loans received from service');
    }
    console.log(this.appliedLoans);
   }, error=>{
    this.router.navigate(['/error'])
  }) 
   }


  public filterByLoanTypeAndDesc() {
    this.ls.getAllLoans().subscribe(data => {
      this.alloans = data;
      this.alloans = this.alloans.filter(p => p.loanType.toLowerCase().includes(this.searchData) || p.description.toLowerCase().includes(this.searchData));
    })
  }

  public deleteLoan(loanId:number){
    this.ls.deleteLoan(loanId).subscribe(data=>{
      this.getAllLoans();
    }, error=>{
      this.router.navigate(['/error'])
    })
  }

  public applyForLoan(loanId: number) {
    this.router.navigate(['/loanform', loanId]);
  }

  
  // public isApplied(loanId: number): boolean {
  //   return this.appliedLoans.some(app => app.Loan === loanId);

  // }
  public isAppliedLoan(chosenloan:Loan){
    for(let l of this.appliedLoans){
      if(l.loan.loanId==chosenloan.loanId){
        return true;
      }
    }
    return false
  }







}
