import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Loan } from 'src/app/models/loan.model';
import { LoanApplication } from 'src/app/models/loanapplication.model';
import { LoanService } from 'src/app/services/loan.service';

@Component({
  selector: 'app-viewloan',
  templateUrl: './viewloan.component.html',
  styleUrls: ['./viewloan.component.css']
})
export class ViewloanComponent implements OnInit {

  loans: Loan[] = [
    // {
    // loanType:"string",
    // description:"string",
    // interestRate:12,
    // maximumAmount:2000,
    // repaymentTenure:2,
    // eligibility:"string",
    // documentsRequired:"string"},
    // {
      
    //   loanType: 'Personal Loan',
    //   maximumAmount: 500000,
    //   interestRate: 10,
    //   repaymentTenure: '5 years',
    //   eligibility: 'Salary > 25000',
    //   documentsRequired: 'Aadhar, PAN, Salary Slip',
    //   description: 'Loan for personal use',
    // }
  ]; 

    showDeleteModal = false;
    loanIdToDelete: number | null = null;
    loanAppilications:LoanApplication[] = [];
    appliedLoanApp : LoanApplication = {}

  constructor(private loanService: LoanService, private router : Router) {} 

  ngOnInit(): void {
    this.fetchLoans();
    this.getAllAppliedLoans(); 
  }

  fetchLoans(): void {
    this.loanService.getAllLoans().subscribe(
      (data) => {
        this.loans = data; 
      },
      (error) => {
        this.router.navigate(['/error']);
      }
    );
  }

  editLoan(loan: any): void {
    console.log('Editing loan:', loan);
    this.router.navigate(['/admineditloan', loan]);

    
  }

  openDeleteModal(loanId: number): void {
    this.loanIdToDelete = loanId;
    this.showDeleteModal = true;
  }

  // Close the delete confirmation modal
  closeDeleteModal(): void {
    this.showDeleteModal = false;
    this.loanIdToDelete = null;
  }

  // Confirm delete action
  confirmDelete(): void {
    console.log("Loan Id")
    console.log(this.loanIdToDelete)
    if (this.loanIdToDelete != null) {
      this.loanService.deleteLoan(this.loanIdToDelete).subscribe(data=>{
        this.fetchLoans();
      },error=> {
        alert("This Loan has been issued to the users and hence cannot be deleted.")
      })
      
    }
    this.closeDeleteModal();
  }

  filter(str: string) {
    this.loanService.getAllLoans().subscribe(data=>{
      this.loans=data;
      this.loans = this.loans.filter(data=>JSON.stringify(data).toLowerCase().includes(str));
    },(error) => {
      this.router.navigate(['/error']);
    })
  }

  getAllAppliedLoans(){
    this.loanService.getAllLoanApplications().subscribe(data=>{
      this.loanAppilications = data;
      this.appliedLoanApp = this.loanAppilications.find(data=>data.loan.loanId==this.loanIdToDelete);
 
 
    })
  }

}

