// package com.examly.springapp.service;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.beans.factory.annotation.Value;
// import org.springframework.stereotype.Service;
// import org.springframework.web.multipart.MultipartFile;

// import com.examly.springapp.model.ImageEntity;
// import com.examly.springapp.repository.ImageRepository;

// import java.io.File;
// import java.io.IOException;
// import java.nio.file.Files;
// import java.nio.file.Path;
// import java.nio.file.Paths;

// @Service
// public class ImageService {

// 	@Value("${file.upload-dir}")
// 	private String uploadDir;

// 	@Autowired
// 	ImageRepository imageRepository;

// 	public ImageEntity uploadImage(MultipartFile file, String title, String description, String uploadedBy,
// 			String uploadDate) throws IOException {
// 		// Create directory if it doesn't exist
// 		File directory = new File(uploadDir);
// 		if (!directory.exists()) {
// 			directory.mkdirs();
// 		}

// 		// Save file to server
// 		String fileName = file.getOriginalFilename();
// 		Path filePath = Paths.get(uploadDir, fileName);
// 		Files.write(filePath, file.getBytes());

// 		// Save file info and metadata to the database
// 		ImageEntity imageEntity = new ImageEntity();
// 		imageEntity.setFileName(fileName);
// 		imageEntity.setFilePath(filePath.toString());
// 		imageEntity.setTitle(title);
// 		imageEntity.setDescription(description);
// 		imageEntity.setUploadedBy(uploadedBy);
// 		imageEntity.setUploadDate(uploadDate);

// 		return imageRepository.save(imageEntity);
// 	}
// }