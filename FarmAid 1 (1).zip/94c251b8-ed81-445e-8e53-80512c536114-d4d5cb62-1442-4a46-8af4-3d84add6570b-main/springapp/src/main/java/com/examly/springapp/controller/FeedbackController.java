package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.exceptions.FeedBackNotFoundException;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.service.FeedbackService;

import java.util.*;

@RestController

public class FeedbackController { 
    
    @Autowired
    private FeedbackService feedbackService;

    @PostMapping("/api/feedback")
    public ResponseEntity<?> createFeedback(@RequestBody Feedback feedback) {
        // feedback not found exceptions

        try{

        Feedback saved = feedbackService.createFeedback(feedback);
        return ResponseEntity.status(201).body(saved);
        }catch(IllegalArgumentException e){
            return ResponseEntity.status(404).body(e.getMessage());

        }

    }

    @GetMapping("/api/feedback/{id}")
    public ResponseEntity<?> viewFeedbackById(@PathVariable Long id) {
        try {
            Feedback saved = feedbackService.getFeedbackById(id);
            return ResponseEntity.status(200).body(saved);
        } catch (FeedBackNotFoundException e) {
            return ResponseEntity.status(401).body(e.getMessage());

        }

    }

    @GetMapping("/api/feedback")
    public ResponseEntity<?> viewAllFeedbacks() {
        // try {
            List<Feedback> saved = feedbackService.getAllFeedback();
            return ResponseEntity.status(200).body(saved);
        // } catch (FeedBackNotFoundException e) {
        //     return ResponseEntity.status(400).body(e.getMessage());
        // }

    }

    @DeleteMapping("/api/feedback/{id}")
    public ResponseEntity<?> deleteFeedback(@PathVariable Long id) {
        try {
            feedbackService.deleteFeedback(id);
            return ResponseEntity.status(200).body("");
        } catch (FeedBackNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    @GetMapping("api/feedback/user/{userId}")
    public ResponseEntity<?> getFeedbackbyUserId(@PathVariable Long userId) {

        try {
            List<Feedback> f = feedbackService.getFeedbacksByUserId(userId);
            return ResponseEntity.status(200).body(f);
        } catch (FeedBackNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }

        
    }
}
