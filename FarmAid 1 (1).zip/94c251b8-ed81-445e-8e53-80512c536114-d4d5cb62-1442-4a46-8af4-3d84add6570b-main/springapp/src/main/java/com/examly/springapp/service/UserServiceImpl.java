package com.examly.springapp.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.DuplicateEmailException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepo;


@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Override
    public User createUser(User user) {
        User existingEmail = userRepo.findByEmail(user.getEmail()).orElse(null);
        if(existingEmail==null){
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            return userRepo.save(user);
        }else{
            throw new DuplicateEmailException("Email already exists!!");
        }
    }

    @Override
    public User loginUser(User user) {
        Optional<User> optUser = userRepo.findByEmail(user.getEmail());
        User existingUser = optUser.get();
        if (existingUser != null && existingUser.getPassword().equals(user.getPassword())) {
            return existingUser;
        } else {
            throw new UserNotFoundException("User not found!!");
        }

    }



    public User getUser(String username){
        return userRepo.findByEmail(username).orElse(null);
    }

    @Override
    public User getUserById(long userId) {
        Optional<User> opt = userRepo.findById(userId);
        if(opt.isEmpty()){
            throw new UserNotFoundException();
        }
        else return opt.get();
        
    }

}

