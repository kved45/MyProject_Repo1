import { Component, OnInit } from '@angular/core';
import { FeedbackService } from 'src/app/services/feedback.service';
import { Feedback } from 'src/app/models/feedback.model'; 
import { User } from 'src/app/models/user.model';

@Component({
  selector: 'app-adminviewfeedback',
  templateUrl: './adminviewfeedback.component.html',
  styleUrls: ['./adminviewfeedback.component.css']
})
export class AdminviewfeedbackComponent implements OnInit {
  
  feedbacks: Feedback[] = [
    // {
    //   "feedbackId":1,
    //   "user": {
    //     "userId": 101,
    //     "email": "john.doe@example.com",
    //     "password": "password123",
    //     "username": "john_doe",
    //     "mobileNumber": "1234567890",
    //     "userRole": "customer"
    //   },
    //   "feedbackText": "Great service!",
    //   "date": new Date()
    // },
    // {
    //   "feedbackId":2,
    //   "user": {
    //     "userId": 102,
    //     "email": "jane.smith@example.com",
    //     "password": "password456",
    //     "username": "jane_smith",
    //     "mobileNumber": "0987654321",
    //     "userRole": "customer"
    //   },
    //   "feedbackText": "Good experience.",
    //   "date": new Date()
    // }

  ];
  currentUser:User={
        "email": "",
        "password": "",
        "username": "",
        "mobileNumber": "",
        "userRole": ""
  };
  showViewModal:boolean = false;
  feedback : Feedback = null;
  // userId:number = +(localStorage.getItem('userId'));

  constructor(private fs: FeedbackService) { }

  ngOnInit(): void {
    this.getAllFeedbacks();
  }

  getAllFeedbacks() {
    this.fs.getFeedbacks().subscribe(data => {
      this.feedbacks = data;
      console.log(data);
    });
  }

  getFeedBackById(id: number) {
    this.showViewModal = true;
    this.feedback = this.feedbacks.find(feedback => feedback.feedbackId === id);
    if (this.feedback) {
      console.log(this.feedback);
      this.currentUser = this.feedback.user;
    } else {
      console.error("Feedback not found");
    }
  }
  

  

  closeviewModal(){
    this.showViewModal=false;
  }

  


  

 
}
