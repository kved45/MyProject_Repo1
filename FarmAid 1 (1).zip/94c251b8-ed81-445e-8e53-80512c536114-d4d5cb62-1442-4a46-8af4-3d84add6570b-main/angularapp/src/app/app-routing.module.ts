import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UseraddfeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { UserviewloanComponent } from './components/userviewloan/userviewloan.component';
import { LoanformComponent } from './components/loanform/loanform.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { LoginComponent } from './components/login/login.component';
import { CreateloanComponent } from './components/createloan/createloan.component';
import { AdminnavComponent } from './components/adminnav/adminnav.component';
import { UsernavComponent } from './components/usernav/usernav.component';
import { ErrorComponent } from './components/error/error.component';
import { AdmineditloanComponent } from './components/admineditloan/admineditloan.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { SignupComponent } from './components/signup/signup.component';
import { UserappliedloanComponent } from './components/userappliedloan/userappliedloan.component';
import { ViewloanComponent } from './components/viewloan/viewloan.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { RequestedloanComponent } from './components/requestedloan/requestedloan.component';

const routes: Routes = [
  {path:'useraddfeedback', component:UseraddfeedbackComponent},
  {path:'adminviewfeedback', component:AdminviewfeedbackComponent},
  {path:'userviewloan', component:UserviewloanComponent},
  {path:'loanform/:id', component:LoanformComponent},
  {path:'userviewfeedback', component:UserviewfeedbackComponent},
  {path:'login', component:LoginComponent},
  {path:'createloan', component:CreateloanComponent},
  {path:'error', component:ErrorComponent},
  {path:'admineditloan/:id', component:AdmineditloanComponent},
  {path:'signup', component:SignupComponent},
  {path:'userappliedloan', component:UserappliedloanComponent},
  {path:'viewloan', component:ViewloanComponent},
  {path:'home-page', component:HomePageComponent},
  {path:'requestedloan', component:RequestedloanComponent},
  {path:'**', component:LoginComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
