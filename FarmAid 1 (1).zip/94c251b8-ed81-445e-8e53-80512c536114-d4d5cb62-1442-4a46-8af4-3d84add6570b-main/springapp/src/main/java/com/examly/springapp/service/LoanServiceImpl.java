package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.LoanNotFoundException;
import com.examly.springapp.model.Loan;
import com.examly.springapp.repository.LoanRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class LoanServiceImpl implements LoanService{

    @Autowired
    private LoanRepo loanRepo;

    @Override 
    public Loan addLoan(Loan loan) {
        if(loan == null){
            throw new EntityNotFoundException("Loan is empty");
        }
        return loanRepo.save(loan);
    }
 
    @Override
    public Loan getLoanById(Long loanId) {
        Optional<Loan> optLoan = loanRepo.findById(loanId);
        if(optLoan.isEmpty()){
            throw new LoanNotFoundException("Loan with Id: "+loanId+" does not exist");
        }
        Loan loan = optLoan.get();
        return loan;
    }

    @Override
    public List<Loan> getAllLoans() {
        List<Loan> loanList = loanRepo.findAll();

        // if(loanList.isEmpty()){
        //     throw new LoanNotFoundException("Loan list is empty");
        // }
        return loanList;
    }

    @Override
    public Loan updateLoan(Long loanId, Loan updatedLoan) {
        Optional<Loan> optloan = loanRepo.findById(loanId);
        
        if(optloan.isEmpty()){
            throw new LoanNotFoundException("Loan with Id: "+loanId+" does not exist");
        }

        Loan existingloan = optloan.get();
        existingloan.setLoanType(updatedLoan.getLoanType());
        existingloan.setDescription(updatedLoan.getDescription());
        existingloan.setInterestRate(updatedLoan.getInterestRate());
        existingloan.setMaximumAmount(updatedLoan.getMaximumAmount());
        existingloan.setRepaymentTenure(updatedLoan.getRepaymentTenure());
        existingloan.setEligibility(updatedLoan.getEligibility());
        existingloan.setDocumentsRequired(updatedLoan.getDocumentsRequired());
        return loanRepo.save(existingloan);
    }

    @Override
    public void deleteLoan(Long loanId) {
        Optional<Loan> optloan = loanRepo.findById(loanId);
        Loan deletedloan = optloan.get();
        
        if(optloan.isEmpty()){
            throw new LoanNotFoundException("Loan with Id: "+loanId+" does not exist");
        }

        loanRepo.deleteById(loanId); 
    }
    
}
