export interface Logindto {
    username ?: string,
    password ?: string
}
