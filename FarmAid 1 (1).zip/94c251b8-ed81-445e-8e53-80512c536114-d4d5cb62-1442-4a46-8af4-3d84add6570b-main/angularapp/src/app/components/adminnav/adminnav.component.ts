import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-adminnav',
  templateUrl: './adminnav.component.html',
  styleUrls: ['./adminnav.component.css']
})
export class AdminnavComponent implements OnInit {

  currentUser:User={
    "email": "",
    "password": "",
    "username": "",
    "mobileNumber": "",
    "userRole": ""
};

  constructor(private router:Router, public authService:AuthService) { }


  ngOnInit(): void {
    this.authService.getUserById(+(localStorage.getItem('userId'))).subscribe(data=>{
      this.currentUser=data;
    })
  }

  logout(){
   localStorage.clear()
   this.router.navigate(['/login']);
  }
}
