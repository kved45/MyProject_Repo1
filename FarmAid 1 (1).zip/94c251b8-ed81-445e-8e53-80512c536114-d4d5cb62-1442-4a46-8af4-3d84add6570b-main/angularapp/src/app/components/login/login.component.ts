import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm : FormGroup;
  errorMessage:boolean;
  constructor(private formBuilder:FormBuilder, private authService : AuthService, private router:Router) { 
    this.loginForm = formBuilder.group({
      username : formBuilder.control("",Validators.required),
      password : formBuilder.control("",Validators.required)
    })
  }

  ngOnInit(): void {
    // localStorage.clear();
  }

  public login(){
    this.authService.login(this.loginForm.value,(returnFlag : boolean)=>{
      this.errorMessage = !returnFlag;
    })
  }

}
