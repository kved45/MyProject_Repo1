import { error } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signupForm: FormGroup;
  showModal: boolean = false;

  constructor(private formBuilder: FormBuilder, private router: Router, private authService: AuthService) {}

  ngOnInit(): void {
    this.signupForm = this.formBuilder.group(
      {
        username: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        mobileNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
        password: ['', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['', Validators.required],
        userRole: ['', Validators.required]
      }
      
    );
  }

  

  onSubmit(): void {
    if (this.signupForm.valid) {
      this.showModal = true; 
      this.authService.register(this.signupForm.value).subscribe(data=>{
        console.log("Inside Register subscribe")
        console.log("Values in signup form"+this.signupForm.value)
        console.log("Data from backend"+data)
      }, error=>{
        this.router.navigate(['/error']);
      })
    }
  }

  redirectToLogin(): void {
    this.showModal = false; 
    this.router.navigate(['/login']); 
  }

  showmodal(){
    this.showModal = true;
  }
}
