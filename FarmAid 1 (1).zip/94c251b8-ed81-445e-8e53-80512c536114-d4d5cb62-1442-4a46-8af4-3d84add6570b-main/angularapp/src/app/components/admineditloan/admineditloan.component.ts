import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Loan } from 'src/app/models/loan.model';
import { LoanService } from 'src/app/services/loan.service';

@Component({
  selector: 'app-admineditloan',
  templateUrl: './admineditloan.component.html',
  styleUrls: ['./admineditloan.component.css']
})
export class AdmineditloanComponent implements OnInit {

  loanForm : FormGroup;
  showModal=false;
  loanIdToEdit: number;

  constructor(private loanService:LoanService,private formBuilder:FormBuilder,private router:Router,private route:ActivatedRoute) { 
    this.loanForm = formBuilder.group({
      loanId: [''],
      loanType: ['', Validators.required],
      description: ['', Validators.required],
      interestRate: ['', Validators.required],
      maximumAmount: ['', Validators.required],
      repaymentTenure: ['', Validators.required],
      eligibility: ['', Validators.required],
      documentsRequired: ['', Validators.required],

    });
  }

  ngOnInit(): void {
    this.route.params.subscribe(d => {
      if (d['id']) {
        this.loanIdToEdit = d['id'];
        this.loadLoanDetails(this.loanIdToEdit);
      }
    },error=>{
      this.router.navigate(['/error']);
    });
  }

  loadLoanDetails(loanId: number): void {
    this.loanService.getLoanById(loanId).subscribe((loan: Loan) => {
      this.loanForm.patchValue(loan);
    });
  }

  onsubmit(): void {
    console.log('Form Validity:', this.loanForm.valid);
    console.log('Form Value:', this.loanForm.value);
    this.showModal = true;

    if (this.loanForm.valid) {
      if (this.loanIdToEdit) {
        this.loanService.updateLoan(this.loanIdToEdit, this.loanForm.value).subscribe(() => {
          this.showModal = true; 
        });
      } else {
        this.loanService.addLoan(this.loanForm.value).subscribe(() => {
          this.showModal = true; 
        });
      }
    }
  }

  closeDeleteModal(){
    this.showModal=false;
    this.router.navigate(['/viewloan']);
  }

}


