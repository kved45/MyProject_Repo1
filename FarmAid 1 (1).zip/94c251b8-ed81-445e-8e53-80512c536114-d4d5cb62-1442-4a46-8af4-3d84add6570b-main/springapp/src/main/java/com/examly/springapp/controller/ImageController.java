// package com.examly.springapp.controller;
// //package com.example.uplaodImage.testImage;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.*;
// import org.springframework.web.multipart.MultipartFile;

// import com.examly.springapp.dto.ImageDto;
// import com.examly.springapp.model.ImageEntity;
// import com.examly.springapp.service.ImageService;
// import com.fasterxml.jackson.databind.ObjectMapper;

// @RestController
// public class ImageController {

// 	@Autowired
// 	ImageService imageService;

// 	@PostMapping("/upload-image")
// 	public ResponseEntity<ImageEntity> uploadImage(@RequestParam("file") MultipartFile file,
// 			@RequestParam("data") String data) {
// 		try {
// 			// Convert JSON string to ImageUploadRequest object
// 			ObjectMapper objectMapper = new ObjectMapper();
// 			ImageDto uploadRequest = objectMapper.readValue(data, ImageDto.class);

// 			// Call the service to handle the upload
// 			ImageEntity imageEntity = imageService.uploadImage(file, uploadRequest.getTitle(),
// 					uploadRequest.getDescription(), uploadRequest.getUploadedBy(), uploadRequest.getUploadDate());

// 			return ResponseEntity.ok(imageEntity);
// 		} catch (Exception e) {
// 			return ResponseEntity.status(500).body(null);
// 		}
// 	}
// }
