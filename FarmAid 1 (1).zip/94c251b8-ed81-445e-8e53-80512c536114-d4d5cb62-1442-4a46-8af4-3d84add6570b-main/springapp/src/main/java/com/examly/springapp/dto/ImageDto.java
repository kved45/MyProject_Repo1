package com.examly.springapp.dto;

public class ImageDto {

    private String title;
    private String description;
    private String uploadedBy;
    private String uploadDate;
 
    public String getTitle() {
        return title;
    }
    
 
    public void setTitle(String title) {
        this.title = title;
    }
 
    public String getDescription() {
        return description;
    }
 
    public void setDescription(String description) {
        this.description = description;
    }
 
    public String getUploadedBy() {
        return uploadedBy;
    }
 
    public void setUploadedBy(String uploadedBy) {
        this.uploadedBy = uploadedBy;
    }
 
    public String getUploadDate() {
        return uploadDate;
    }
 
    public void setUploadDate(String uploadDate) {
        this.uploadDate = uploadDate;
    }
}
    

