import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { FeedbackService } from 'src/app/services/feedback.service';
import { LoanService } from 'src/app/services/loan.service';

@Component({
  selector: 'app-userviewfeedback',
  templateUrl: './userviewfeedback.component.html',
  styleUrls: ['./userviewfeedback.component.css']
})
export class UserviewfeedbackComponent implements OnInit {

  showDeleteModal : boolean = false;
  deleteId : number; 

  feedbacks : Feedback[] = [
    // { feedbackId: 1, userId: 101, feedbackText: 'Great service!', date: new Date('2022-01-01') },
    // { feedbackId: 2, userId: 102, feedbackText: 'Very satisfied with the loan process.', date: new Date('2022-01-15') },
    // { feedbackId: 3, userId: 103, feedbackText: 'Customer support was very helpful.', date: new Date('2022-02-10') },
    // { feedbackId: 4, userId: 104, feedbackText: 'Loan approval was quick and easy.', date: new Date('2022-03-05') },
    // { feedbackId: 5, userId: 105, feedbackText: 'Excellent experience!', date: new Date}
  ];

  constructor(private feedBackService : FeedbackService, private router : Router) { }

  ngOnInit(): void {
    this.getFeedbacksByUserId();
  }

  public getFeedbacksByUserId(){
    console.log("I am inside userviewfeedback method")
    this.feedBackService.getAllFeedbacksByUserId(+(localStorage.getItem('userId'))).subscribe(d=>{

      this.feedbacks = d;
    }, error=>{
      this.router.navigate(['/error'])
    })
  }

  public deleteFeedBack(id:number){
    console.log("Inside deleteFeedback but not confirm delete.")
    this.showDeleteModal = true;
    this.deleteId = id;
  }

  public closeDeleteModal(){
    this.showDeleteModal = false;
  }

  public confirmDelete(){

    this.feedBackService.deleteFeedback(this.deleteId).subscribe(d=>{
      console.log("Inside the subscribe of deleteFeedback")
      this.showDeleteModal=false;
      this.getFeedbacksByUserId();
    }
    // , error=>{
    //   this.router.navigate(['/error'])
    // }
    )
  }

}
