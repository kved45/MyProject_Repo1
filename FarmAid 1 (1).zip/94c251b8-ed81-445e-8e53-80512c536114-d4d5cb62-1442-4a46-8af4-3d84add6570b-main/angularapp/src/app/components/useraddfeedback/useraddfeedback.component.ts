import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model'; // Adjust the import path as necessary
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-useraddfeedback',
  templateUrl: './useraddfeedback.component.html',
  styleUrls: ['./useraddfeedback.component.css']
})
export class UseraddfeedbackComponent implements OnInit {
  feedbackForm: FormGroup;
  showmodal:boolean = false;

  constructor(private fb: FormBuilder, private fs:FeedbackService, private router:Router){ 
    this.feedbackForm = this.fb.group({
      feedbackText: ['', [Validators.required]]
    });

  }
  

  ngOnInit(): void {
   
  }

  public onSubmit() {
    if (this.feedbackForm.valid) {
      let feedback:Feedback={
        user:{
                userId:parseInt(localStorage.getItem("userId")),
                email:"",
                password:"",
                username:"",
                mobileNumber:"",
                userRole:""

              }
        ,feedbackText: this.feedbackForm.value.feedbackText,
        date: new Date()
      }
      if(this.feedbackForm.valid){
        this.fs.sendFeedback(feedback).subscribe(data=>{
          this.feedbackForm.reset();

          
      }, error=>{
        this.router.navigate(['/error'])
      })
      
    }
     
  }
      
  }

  showModal(){
    this.showmodal = true;
  }
  
  closeModal(){
    this.showmodal = false;
    this.router.navigate(['/userviewfeedback'])
  }
}


