import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-usernav',
  templateUrl: './usernav.component.html',
  styleUrls: ['./usernav.component.css']
})
export class UsernavComponent implements OnInit {

  currentUser:User={
    "email": "",
    "password": "",
    "username": "",
    "mobileNumber": "",
    "userRole": ""
};

  constructor(private router: Router, private authService:AuthService) { }

  ngOnInit(): void {
    this.authService.getUserById(+(localStorage.getItem('userId'))).subscribe(data=>{
      this.currentUser=data;
    })
  }

  logout(){
    localStorage.clear()
    this.router.navigate(['/login']);
   }

}
