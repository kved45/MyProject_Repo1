package com.examly.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.FeedBackNotFoundException;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.repository.FeedbackRepo;

import java.util.*;

@Service
public class FeedbackServiceImpl implements FeedbackService {
     

    @Autowired
    private FeedbackRepo feedbackRepo;

    @Override
    public Feedback createFeedback(Feedback feedback) {
        if(feedback.getFeedbackText()==null){
            throw new IllegalArgumentException("Cant add");
        }else{
            return feedbackRepo.save(feedback);
        }


    }

    @Override
    public Feedback getFeedbackById(Long id) {
        Optional<Feedback> opt = feedbackRepo.findById(id);
        if (opt.isEmpty()) {
            throw new FeedBackNotFoundException("Feedback with Id " + id + " not found");

        } else {
            return opt.get();

        }

    }

    @Override
    public List<Feedback> getAllFeedback() {
        List<Feedback> opt = feedbackRepo.findAll();
        // if (opt.isEmpty()) {
        //     throw new FeedBackNotFoundException("Feedbacks not found");

        // } else {
            return feedbackRepo.findAll();

        //}

    }

    @Override
    public void deleteFeedback(Long id) {
        if (feedbackRepo.existsById(id)) {
            feedbackRepo.deleteById(id);
        } else {
            throw new FeedBackNotFoundException("Id not exists");

        }
    }

    @Override
    public List<Feedback> getFeedbacksByUserId(Long userId) {
        List<Feedback> exists=feedbackRepo.findByUser(userId);
        // if(exists.isEmpty()){
        //     throw new FeedBackNotFoundException("List not found");

        // }else{
            return feedbackRepo.findByUser(userId);
        // }



    
}
}