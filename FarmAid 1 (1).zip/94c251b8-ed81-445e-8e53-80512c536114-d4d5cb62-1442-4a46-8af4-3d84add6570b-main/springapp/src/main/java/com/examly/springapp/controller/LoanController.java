package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.exceptions.DuplicateLoanException;
import com.examly.springapp.exceptions.LoanNotFoundException;
import com.examly.springapp.model.Loan;
import com.examly.springapp.service.LoanService;
import com.examly.springapp.service.LoanServiceImpl;

import jakarta.persistence.EntityNotFoundException;

@RestController
public class LoanController {

    @Autowired 
    private LoanServiceImpl loanServiceImpl;

    @PostMapping("/api/loan")
    public ResponseEntity<?> addLoan(@RequestBody Loan loan){
        try{
            Loan savedloan = loanServiceImpl.addLoan(loan);
            return ResponseEntity.status(201).body(savedloan);
        }
        catch(EntityNotFoundException e){ 
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

    @GetMapping("/api/loan/{loanId}")
    public ResponseEntity<?> getLoanById(@PathVariable long loanId){
        try{
            Loan loan = loanServiceImpl.getLoanById(loanId);
            return ResponseEntity.status(200).body(loan);
        }
        catch(LoanNotFoundException e){
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    @GetMapping("/api/loan")
    public ResponseEntity<?> getAllLoans(){
        // try{
            List<Loan> loanlist = loanServiceImpl.getAllLoans();
            return ResponseEntity.status(200).body(loanlist);
        // }
        // catch(LoanNotFoundException e){
        //     return ResponseEntity.status(400).body(e.getMessage());
        // }
        
    }

    @PutMapping("/api/loan/{loanId}")
    public ResponseEntity<?> updateLoan(@PathVariable long loanId, @RequestBody Loan loan){
        try{
            Loan updateloan = loanServiceImpl.updateLoan(loanId, loan);
            return ResponseEntity.status(200).body(updateloan);
        }
        catch(LoanNotFoundException e){
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    @DeleteMapping("/api/loan/{loanId}")
    public ResponseEntity<?> deleteLoan(@PathVariable long loanId){
        try{
            loanServiceImpl.deleteLoan(loanId);
            return ResponseEntity.status(200).body("Deleted successfully");
        }
        catch(LoanNotFoundException e){
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }
    
}
