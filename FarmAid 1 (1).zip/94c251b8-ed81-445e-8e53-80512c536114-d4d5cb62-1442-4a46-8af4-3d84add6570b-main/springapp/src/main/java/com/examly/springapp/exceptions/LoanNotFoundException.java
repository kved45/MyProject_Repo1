package com.examly.springapp.exceptions;

public class LoanNotFoundException extends RuntimeException{

    LoanNotFoundException(){

    } 
    
    public LoanNotFoundException(String message){
                super(message);
    }
}
