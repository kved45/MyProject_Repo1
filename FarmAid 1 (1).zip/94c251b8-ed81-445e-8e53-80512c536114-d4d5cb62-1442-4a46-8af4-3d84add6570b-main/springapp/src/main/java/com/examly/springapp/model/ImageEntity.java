// package com.examly.springapp.model;
// import jakarta.persistence.*;
// //package com.example.uplaodImage.testImage;

// @Entity
// public class ImageEntity {

//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;

//     @Column(nullable = false)
//     private String fileName;

//     @Column(nullable = false)
//     private String filePath;

//     @Column(nullable = false)
//     private String title;

//     @Column
//     private String description;

//     @Column
//     private String uploadedBy;

//     @Column
//     private String uploadDate;

//     public Long getId() {
//         return id;
//     }

//     public void setId(Long id) {
//         this.id = id;
//     }

//     public String getFileName() {
//         return fileName;
//     }

//     public void setFileName(String fileName) {
//         this.fileName = fileName;
//     }

//     public String getFilePath() {
//         return filePath;
//     }

//     public void setFilePath(String filePath) {
//         this.filePath = filePath;
//     }

//     public String getTitle() {
//         return title;
//     }

//     public void setTitle(String title) {
//         this.title = title;
//     }

//     public String getDescription() {
//         return description;
//     }

//     public void setDescription(String description) {
//         this.description = description;
//     }

//     public String getUploadedBy() {
//         return uploadedBy;
//     }

//     public void setUploadedBy(String uploadedBy) {
//         this.uploadedBy = uploadedBy;
//     }

//     public String getUploadDate() {
//         return uploadDate;
//     }

//     public void setUploadDate(String uploadDate) {
//         this.uploadDate = uploadDate;
//     }
    
// }
