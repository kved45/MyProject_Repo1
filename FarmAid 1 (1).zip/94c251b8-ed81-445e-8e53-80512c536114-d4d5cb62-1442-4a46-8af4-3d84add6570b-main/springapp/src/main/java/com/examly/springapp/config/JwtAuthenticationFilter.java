package com.examly.springapp.config;

public class JwtAuthenticationFilter {
    
}
