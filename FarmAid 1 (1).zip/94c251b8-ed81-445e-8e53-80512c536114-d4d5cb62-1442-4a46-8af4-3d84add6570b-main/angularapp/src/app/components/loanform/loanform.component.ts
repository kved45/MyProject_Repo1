import { error } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Loan } from 'src/app/models/loan.model';
import { LoanApplication } from 'src/app/models/loanapplication.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { LoanService } from 'src/app/services/loan.service';

@Component({
  selector: 'app-loanform',
  templateUrl: './loanform.component.html',
  styleUrls: ['./loanform.component.css']
})
export class LoanformComponent implements OnInit {

  loanForm : FormGroup;
  submitted : boolean = false;
  showConfirmModal : boolean = false;
  loan:Loan={
    loanType:"",
    description:"",
    interestRate:0,
    maximumAmount:0,
    repaymentTenure:0,
    eligibility:"",
    documentsRequired:""
  };

  currentUser:User = {
    email:"",
    password:"",
    username:"",
    mobileNumber:"",
    userRole:""
  };


  constructor(private formBuilder : FormBuilder, private router : Router, private loanService : LoanService, private activatedRoute:ActivatedRoute, private authService:AuthService) {
    this.loanForm = formBuilder.group({
      farmLocation : formBuilder.control("",Validators.required),
      farmerAddress : formBuilder.control("",Validators.required),
      farmSizeInAcres : formBuilder.control("",[Validators.required, Validators.min(0)]),
      farmPurpose : formBuilder.control("",Validators.required),
      farmFile : formBuilder.control("")
    })
   }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(param=>{
      let loanId:number = param['id'];
      this.loanService.getLoanById(loanId).subscribe(data=>{
        this.loan=data;
        console.log("Loan Data:")
        console.log(this.loan);
      }, error=>{
        this.router.navigate(['/error']);
      })
    })

    this.authService.getUserById(+(localStorage.getItem('userId'))).subscribe(data=>{
      this.currentUser = data;
      console.log("User Data:")
        console.log(this.currentUser);
    })

    
  }

  public onSubmit(){
    
    if(this.loanForm.valid){
      this.showConfirmModal = true;
      let loanApp:LoanApplication = {
        user:this.currentUser,
        loan:this.loan,
        submissionDate:new Date(),
        loanStatus:0,
        farmLocation:this.loanForm.value.farmLocation,
        farmerAddress:this.loanForm.value.farmerAddress,
        farmSizeInAcres:this.loanForm.value.farmSizeInAcres,
        farmPurpose:this.loanForm.value.farmPurpose,
        file:"string"
      }
      this.loanService.addLoanApplication(loanApp).subscribe(d=>{
        this.router.navigate(['/userviewloan']);//navigates to userviewloan component
      }, error=>{
        this.router.navigate(['/error'])
      })
      
    }
    else if(this.loanForm.invalid){
      this.submitted = true;
    }

  }

  closeModal(){
    this.showConfirmModal=false;
  }

  

  public goBack(){
    this.router.navigate(['/userviewloan']);//navigates to userviewloan component
  }

  
}
