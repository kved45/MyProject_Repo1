package com.examly.springapp.exceptions;


public class FeedBackNotFoundException extends RuntimeException  {

    public FeedBackNotFoundException(){

    }

    public FeedBackNotFoundException(String message){ 
        super(message);

    }
 
}
