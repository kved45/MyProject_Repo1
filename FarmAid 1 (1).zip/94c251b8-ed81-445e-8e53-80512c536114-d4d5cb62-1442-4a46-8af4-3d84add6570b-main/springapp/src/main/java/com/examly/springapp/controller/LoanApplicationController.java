package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.exceptions.LoanApplicationNotFoundException;
import com.examly.springapp.model.LoanApplication;
import com.examly.springapp.service.LoanApplicationService;

@RestController
@RequestMapping("/api")
public class LoanApplicationController {

    @Autowired
    private LoanApplicationService loanApplicationService;

    @PostMapping("/loanapplication")
    public ResponseEntity<?> addLoanApplication(@RequestBody LoanApplication loanApplication) {
        try {
            return ResponseEntity.status(201).body(loanApplicationService.addLoanApplication(loanApplication));
        } catch (LoanApplicationNotFoundException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

    @GetMapping("/loanapplication/{loanApplicationId}")
    public ResponseEntity<?> getLoanApplicationbyId(@PathVariable Long loanApplicationId) {
        try {
            return ResponseEntity.status(200).body(loanApplicationService.getLoanApplicationbyId(loanApplicationId));
        } catch (LoanApplicationNotFoundException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

    @GetMapping("/loanapplication/user/{userId}")
    public ResponseEntity<?> getLoanApplicationByUserId(@PathVariable Long userId) {
        try {
            return ResponseEntity.status(200).body(loanApplicationService.getLoanApplicationByUserId(userId));
        } catch (LoanApplicationNotFoundException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

    @GetMapping("/loanapplication")
    public ResponseEntity<?> getAllLoanAppilications() {
        try {
            return ResponseEntity.status(200).body(loanApplicationService.getAllLoanAppilications());
        } catch (LoanApplicationNotFoundException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

    @PutMapping("/loanapplication/{loanApplicationId}")
    public ResponseEntity<?> updateLoanAppilication(@PathVariable Long loanApplicationId,
            @RequestBody LoanApplication loanApplication) {
        try {
            return ResponseEntity.status(200)
                    .body(loanApplicationService.updateLoanAppilication(loanApplicationId, loanApplication));
        } catch (LoanApplicationNotFoundException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

    @DeleteMapping("/loanapplication/{loanApplicationId}")
    public ResponseEntity<?> deleteLoanApplication(@PathVariable Long loanApplicationId) {
        try {
            loanApplicationService.deleteLoanApplication(loanApplicationId);
            return ResponseEntity.status(200).body("Successfully Deleted");
        } catch (LoanApplicationNotFoundException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

}
