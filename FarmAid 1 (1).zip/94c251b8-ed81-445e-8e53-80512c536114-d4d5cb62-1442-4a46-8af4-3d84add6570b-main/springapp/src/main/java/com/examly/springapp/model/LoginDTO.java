package com.examly.springapp.model;

public class LoginDTO {
    
}
