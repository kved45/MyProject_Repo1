import { error } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoanApplication } from 'src/app/models/loanapplication.model';
import { LoanService } from 'src/app/services/loan.service';

@Component({
  selector: 'app-requestedloan',
  templateUrl: './requestedloan.component.html',
  styleUrls: ['./requestedloan.component.css']
})
export class RequestedloanComponent implements OnInit {

  loanApplications:LoanApplication[]=[
  //   {loanApplicationId:1,
  //   user:{
  //     userId:1,
  //     email:"string",
  //     password:"demostring",
  //     username:"demo username",
  //     mobileNumber:"string",
  //     userRole:"string"

  //   },
  //   loan:{
  //     loanId:1,
  //     loanType:"Compound",
  //     description:"description string",
  //     interestRate:2,
  //     maximumAmount:100000,
  //     repaymentTenure:4,
  //     eligibility:"eligible",
  //     documentsRequired:"required documents"
  //   },
  //   submissionDate:"12-12-2001",
  //   loanStatus:0,
  //   farmLocation:"Mumbai",
  //   farmerAddress:"Navi Mumbai",
  //   farmSizeInAcres:10,
  //   farmPurpose:"Good purpose",
  //   file:"Demo file"
  // }
  ]

  constructor(private loanService:LoanService, private router:Router) { }

  ngOnInit(): void {
    this.getAllApplicationLoans();
  }

  public getAllApplicationLoans(){
    return this.loanService.getAllLoanApplications().subscribe(data=>{
      this.loanApplications=data;
    }, error=>{
      this.router.navigate(['/error'])
    })
  }

  public changeStatusToApproved(id:number, la:LoanApplication){
    la.loanStatus=1;
    return this.loanService.updateLoanStatus(id, la).subscribe(data=>{
      this.getAllApplicationLoans();
    }, error=>{
      this.router.navigate(['/error'])
    })
  }

  public changeStatusToRejected(id:number, la:LoanApplication){
    la.loanStatus=2;
    return this.loanService.updateLoanStatus(id, la).subscribe(data=>{
      this.getAllApplicationLoans();
    }, error=>{
      this.router.navigate(['/error'])
    })

    
  }

}
