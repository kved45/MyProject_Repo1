import { Loan } from "./loan.model";
import { User } from "./user.model";

export interface LoanApplication {

    loanApplicationId?:number,

    user?:User,
    loan?:Loan,
    submissionDate?:Date,
    loanStatus?:number,
    farmLocation?:string,
    farmerAddress?:string,
    farmSizeInAcres?:number,
    farmPurpose?:string,
    file?:string

}
