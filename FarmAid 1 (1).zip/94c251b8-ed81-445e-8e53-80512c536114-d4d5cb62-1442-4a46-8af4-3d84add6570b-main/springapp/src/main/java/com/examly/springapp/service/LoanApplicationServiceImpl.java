package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.LoanApplicationNotFoundException;
import com.examly.springapp.model.LoanApplication;
import com.examly.springapp.repository.LoanApplicationRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class LoanApplicationServiceImpl implements LoanApplicationService {

    @Autowired
    private LoanApplicationRepo loanApplicationRepo;

    @Override
    public LoanApplication addLoanApplication(LoanApplication loanApplication) {
        if(loanApplication == null){
            throw new LoanApplicationNotFoundException("Not a Valid LoanAppilication");
        }else{
            LoanApplication savedLoanApplication = loanApplicationRepo.save(loanApplication);
            return savedLoanApplication;
        }
        
    }

    @Override
    public List<LoanApplication> getLoanApplicationByUserId(Long userId) {

       List<LoanApplication> laList = loanApplicationRepo.getLoanApplicationByUserId(userId);
    //    if(laList.isEmpty()){
    //         // LoanAppilicationNotFound
    //         throw new LoanApplicationNotFoundException("There are no loanAppilications in the list with userID "+userId);
    //    }else{
        return laList;
    //    }

    }

    @Override
    public LoanApplication getLoanApplicationbyId(Long loanApplicationId) {
        LoanApplication loanApplication = loanApplicationRepo.findById(loanApplicationId).orElse(null);
        if (loanApplication == null) {
            // laonApplication not found exception
            throw new LoanApplicationNotFoundException("Loan Application with id " + loanApplicationId + " not found");
        } else {
            return loanApplication;
        }
    }

    @Override
    public List<LoanApplication> getAllLoanAppilications() {
        List<LoanApplication> loanAppList = loanApplicationRepo.findAll();
        if (loanAppList.isEmpty()) {
            // LoanAppilicationNotFound
            throw new LoanApplicationNotFoundException("There are no loanAppilications in the list.");
        } else {
            return loanAppList;
        }
    }

    @Override
    public LoanApplication updateLoanAppilication(Long loanApplicationId, LoanApplication updatedLoanApplication) {
        Optional<LoanApplication> optionalLoanApplication = loanApplicationRepo.findById(loanApplicationId);

        if (optionalLoanApplication.isPresent()) {
            LoanApplication existingLoanApplication = optionalLoanApplication.get();

            existingLoanApplication.setSubmissionDate(updatedLoanApplication.getSubmissionDate());
            existingLoanApplication.setLoanStatus(updatedLoanApplication.getLoanStatus());
            existingLoanApplication.setFarmLocation(updatedLoanApplication.getFarmLocation());
            existingLoanApplication.setFarmerAddress(updatedLoanApplication.getFarmerAddress());
            existingLoanApplication.setFarmSizeInAcres(updatedLoanApplication.getFarmSizeInAcres());
            existingLoanApplication.setFarmPurpose(updatedLoanApplication.getFarmPurpose());
            existingLoanApplication.setFile(updatedLoanApplication.getFile());
            existingLoanApplication.setUser(updatedLoanApplication.getUser());
            existingLoanApplication.setLoan(updatedLoanApplication.getLoan());

            return loanApplicationRepo.save(existingLoanApplication);
        } else {
            // LoanApplication not found exception
            throw new LoanApplicationNotFoundException("LoanApplication not found with ID: " + loanApplicationId);
        }
    }

    @Override
    public void deleteLoanApplication(Long loanApplicationId) {
        LoanApplication loanApplication = loanApplicationRepo.findById(loanApplicationId).orElse(null);
        if (loanApplication == null) {
            // laonApplication not found exception
            throw new LoanApplicationNotFoundException(
                    "Loan Application with id " + loanApplicationId + " not found for deleting.");
        } else {
            loanApplicationRepo.deleteById(loanApplicationId);
        }
    }

}
