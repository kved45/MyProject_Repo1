package com.examly.springapp.service;

import java.util.List;
import com.examly.springapp.model.LoanApplication;

public interface LoanApplicationService  {
    public LoanApplication addLoanApplication(LoanApplication loanApplication);
    public List<LoanApplication> getLoanApplicationByUserId(Long userId);
    public LoanApplication getLoanApplicationbyId(Long loanApplicationId);
    public List<LoanApplication> getAllLoanAppilications();
    public LoanApplication updateLoanAppilication(Long loanApplicationId, LoanApplication updatedLoanApplication);
    public void deleteLoanApplication(Long loanApplicationId);
}
