import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoanService } from 'src/app/services/loan.service';

@Component({
  selector: 'app-createloan',
  templateUrl: './createloan.component.html',
  styleUrls: ['./createloan.component.css']
})
export class CreateloanComponent implements OnInit {
  loanForm: FormGroup;
  showModal = false;

  constructor(
    private loanService: LoanService,
    private formBuilder: FormBuilder,
    private router: Router
  ) {
    this.loanForm = this.formBuilder.group({
      // loanId: ['', Validators.required],
      loanType: ['', Validators.required],
      description: ['', Validators.required],
      interestRate: ['', Validators.required],
      maximumAmount: ['', Validators.required],
      repaymentTenure: ['', Validators.required],
      eligibility: ['', Validators.required],
      documentsRequired: ['', Validators.required],
    });
  }

  ngOnInit(): void {}

  onsubmit(): void {
    console.log('Form Validity:', this.loanForm.valid);
    console.log('Form Value:', this.loanForm.value);
    this.showModal = true;
    if (this.loanForm.valid) {
      this.loanService.addLoan(this.loanForm.value).subscribe(() => {
        this.showModal = true; 
      },error=>{
        this.router.navigate(['/error']);
      });
    }
  }

  redirectToPage(): void {
    this.showModal = false; 
    this.router.navigate(['/viewloan']); 
  }
}
