package com.examly.springapp.exceptions;

public class LoanApplicationNotFoundException extends RuntimeException{

    public LoanApplicationNotFoundException(){

    }

    public LoanApplicationNotFoundException(String message){
        super(message);
    }
    
}
