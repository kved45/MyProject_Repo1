package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.config.JwtUtils;
import com.examly.springapp.dto.LoginRequestDto;
import com.examly.springapp.dto.LoginResponseDto;
import com.examly.springapp.exceptions.DuplicateEmailException;
import com.examly.springapp.model.User;
import com.examly.springapp.service.UserService;
import com.examly.springapp.service.UserServiceImpl;

import jakarta.persistence.EntityNotFoundException;

@RestController

public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtils jwtService;

    @PostMapping("/api/register")
    public ResponseEntity<?> createUser(@RequestBody User user) {
        try {
            return ResponseEntity.status(201).body(userService.createUser(user));
        } catch (DuplicateEmailException e) {
            return ResponseEntity.status(405).body("Duplicate credentials..");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(409).body("Illegal argument");
        }

    }

        @PostMapping("/api/login")
        @PreAuthorize("permitAll()")
        public LoginResponseDto AuthenticateAndGetToken(@RequestBody LoginRequestDto user){
            Authentication authentication = authenticationManager
                                        .authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
            if(authentication.isAuthenticated()){
                User responseUser =userService.getUser(user.getUsername());
                LoginResponseDto reponse=new LoginResponseDto();
                reponse.setJwtToken(jwtService.generateToken(user.getUsername()));
                reponse.setUserId(responseUser.getUserId());
                reponse.setUsername(responseUser.getEmail());
                reponse.setRole(responseUser.getUserRole());
                return reponse;

                
            }
            else {
                throw new UsernameNotFoundException("invalid user request..!!");
            }
        }


    @GetMapping("/api/user/{userId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> getUserById(@PathVariable long userId){
        // System.out.println("===================================");
        // System.out.println("===================================");
        // System.out.println("===================================");
        return ResponseEntity.status(200).body(userService.getUserById(userId));
    }
    
}


