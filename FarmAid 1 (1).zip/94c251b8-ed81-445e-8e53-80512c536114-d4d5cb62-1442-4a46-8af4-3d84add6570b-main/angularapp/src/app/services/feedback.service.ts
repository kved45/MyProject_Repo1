import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Feedback } from '../models/feedback.model';
import { Observable } from 'rxjs';
import { globalUrl } from '../globals/global-url';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
 
  public apiUrl:string = globalUrl+"api/feedback";

  constructor(private httpClient:HttpClient) { }

  public sendFeedback(feedback:Feedback):Observable<Feedback>{
    return this.httpClient.post<Feedback>(this.apiUrl,feedback);
  }

  public getAllFeedbacksByUserId(userId:number):Observable<Feedback[]>{
    return this.httpClient.get<Feedback[]>(this.apiUrl+"/user/"+userId);
  }

  public deleteFeedback(feedbackId:number):Observable<void>{
    return this.httpClient.delete<void>(this.apiUrl+"/"+feedbackId);
  }

  public getFeedbacks():Observable<Feedback[]>{
    return this.httpClient.get<Feedback[]>(this.apiUrl);
  }
}
