import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Loan } from '../models/loan.model';
import { LoanApplication } from '../models/loanapplication.model';
import { globalUrl} from '../globals/global-url';

@Injectable({
  providedIn: 'root'
})
export class LoanService {

  public apiUrl:string = globalUrl+"api";

  constructor(private httpClient:HttpClient) { }

  public getAllLoans():Observable<Loan[]>{
    return this.httpClient.get<Loan[]>(this.apiUrl+"/loan");
  }

  public deleteLoan(loanId:number):Observable<void>{
    return this.httpClient.delete<void>(this.apiUrl+"/loan/"+loanId);
  }

  public getLoanById(loanId:number):Observable<Loan>{
    return this.httpClient.get<Loan>(this.apiUrl+"/loan/"+loanId);
  }

  public addLoan(requestObject:Loan): Observable<Loan>{
    return this.httpClient.post<Loan>(this.apiUrl+"/loan",requestObject);
  }

  public updateLoan(id:number, requestObject:Loan):Observable<Loan>{
    return this.httpClient.put<Loan>(this.apiUrl+"/loan/"+id, requestObject);
  }

  public getAppliedLoans(userId:number):Observable<LoanApplication[]>{
    return this.httpClient.get<LoanApplication[]>(this.apiUrl+"/loanapplication/user/"+userId);
  }

  public deleteLoanApplication(loanId:number):Observable<void>{
    return this.httpClient.delete<void>(this.apiUrl+"/loanapplication/"+loanId);
  }

  public addLoanApplication(data:LoanApplication):Observable<LoanApplication>{
    return this.httpClient.post<LoanApplication>(this.apiUrl+"/loanapplication",data);
  }

  public getAllLoanApplications():Observable<LoanApplication[]>{
    return this.httpClient.get<LoanApplication[]>(this.apiUrl+"/loanapplication");
  }

  public updateLoanStatus(id:number, loanapplication:LoanApplication):Observable<LoanApplication>{
    return this.httpClient.put<LoanApplication>(this.apiUrl+"/loanapplication/"+id, loanapplication);
  }
}
